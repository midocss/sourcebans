$(document).ready(function(){
	$('#srv-table a.up, #srv-table a.dn').click(move_row);

});
