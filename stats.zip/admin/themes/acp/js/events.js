$(document).ready(function(){
	$('#ev-table a.up, #ev-table a.dn').click(move_row);
});
