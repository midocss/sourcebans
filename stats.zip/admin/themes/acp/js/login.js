$(document).ready(function() { 
	$('input[@name=username]').focus();
});
