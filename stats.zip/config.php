<?php
$dbtype = 'mysql';
$dbhost = 'localhost';
$dbport = '';
$dbname = 'psychostats3_1';
$dbuser = 'ps3';
$dbpass = '';
$dbtblprefix = 'ps_';
?>
