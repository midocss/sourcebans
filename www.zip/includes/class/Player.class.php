<?php
/**
 * @author Lord FEAR
 */

class Player {
    public $steamid, $name, $value, $lvl, $kills, $death, $kd, $shot, $hits_all, $hits_head, $hits_chest, $hits_stomach, $hits_arms, $hits_legs, $acc, $inhead, $help, $lastgame, $maxLvl;

    public function __construct($steamid){
        if(preg_match("/STEAM/", $steamid)){
            $this->steamid = $steamid;
        }else {
            $srx = (substr($steamid, -1) % 2 == 0) ? 0 : 1;
            $arx = bcsub($steamid, "76561197960265728");
            if (bccomp($arx, "0") != 1) { throw new InvalidArgumentException("Invalid SteamID"); }
            $arx = bcsub($arx, $srx);
            $arx = bcdiv($arx, 2);            
            $this->steamid = sprintf("STEAM_1:%s:%s", $srx, $arx);
        }
    }    

    public function getMaxLvl($config){
        for($i=0; $i<count($config['server']); $i++){
            $server = new Server($config['server'][$i]['name'], $config['server'][$i]['host'], $config['server'][$i]['dbName'], $config['server'][$i]['login'], $config['server'][$i]['pass'], $config['server'][$i]['port']);
            $lvlarr[$i] = $this->getLvlOnServer($server);
            unset($server);
        }
        return $lvlarr;
    }

    function getLvlOnServer($server){
        $pdo = $this->connect($server);
        $stmt = $pdo->prepare("SELECT rank FROM lvl_base WHERE steam = :steam");
        $stmt->execute(array(':steam' => $this->steamid));	
	    unset($pdo);
        $lvl = $stmt->fetchColumn();
        return $lvl;
    }
    
    function getStat($server) {
    $pdo = $this->connect($server);
    $stmt = $pdo->prepare("SELECT * FROM lvl_base WHERE steam = :steam");
	$stmt->execute(array(':steam' => $this->steamid));	
	unset($pdo);
	$stat = $stmt->fetch();
        if(!$stat){
            $this->name = NULL;
            $this->value = NULL;
            $this->lvl = NULL;
            $this->kills = NULL;
            $this->death = NULL;
            $this->kd = NULL;
            $this->shot = NULL;
            $this->hits_all = NULL;
			$this->hits_head = NULL;
			$this->hits_chest = NULL;
			$this->hits_stomach = NULL;
			$this->hits_arms = NULL;
			$this->hits_legs = NULL;
            $this->acc = NULL;
            $this->inhead = NULL;
            $this->help = NULL;
            $this->lastgame = NULL;
        }else{
            $this->name = $stat['name'];
            $this->value = $stat['value'];
            $this->lvl = $stat['rank'];
            $this->kills = $stat['kills'];
            $this->death = $stat['deaths'];
            if($this->death!=0){
                $this->kd = round($this->kills / $this->death, 2);
            }else{
                $this->kd = $this->kills;
            }
            $this->shot = $stat['shoots'];
            $this->hits_all = $stat['hits_all'];
			$this->hits_head = $stat['hits_head'];
			$this->hits_chest = $stat['hits_chest'];
			$this->hits_stomach = $stat['hits_stomach'];
			$this->hits_arms = $stat['hits_arms'];
			$this->hits_legs = $stat['hits_legs'];
            if($this->shot!=0){
                $this->acc = round($this->hits_all * 100 / $this->shot);
            }else{
                $this->acc = 0;
            }
            $this->inhead = $stat['headshots'];
            $this->help = $stat['assists'];
            $this->lastgame = $stat['lastconnect']; 
        }     
    }

    function getSteamid(){
        return $this->steamid;
    }
    function setSteamid($steamid){
        $this->steamid = $steamid;
    }

    function getName(){
        return $this->name;
    }
    function setName($name){
        $this->name = $name;
    }

    function getValue(){
        return $this->value;
    }
    function setValue($value){
        $this->value = $value;
    }

    function getLvl(){
        return $this->lvl;
    }
    function setLvl($lvl){
        $this->lvl = $lvl;
    }

    function getKills(){
        return $this->kills;
    }
    function setKills($kills){
        $this->kills = $kills;
    }

    function getDeath(){
        return $this->death;
    }
    function setDeath($death){
        $this->death = $death;
    }

    function getKd(){
        return $this->kd;
    }
    function setKd(){
        $this->kd = round($this->kills / $this->death, 2);
    }

    function getShot(){
        return $this->shot;
    }
    function setShot($shot){
        $this->shot = $shot;
    }

    function getHits_all(){
        return $this->hits_all;
    }
    function setHits_all($hits_all){
        $this->hits_all = $hits_all;
    }
	   
	function getHits_head(){
        return $this->hits_head;
    }
    function setHits_head($hits_head){
        $this->hits_head = $hits_head;
    }
	
	function getHits_chest(){
        return $this->hits_chest;
    }
    function setHits_chest($hits_chest){
        $this->hits_chest = $hits_chest;
    }
	
	function getHits_stomach(){
        return $this->hits_stomach;
    }
    function setHits_stomach($hits_stomach){
        $this->hits_stomach = $hits_stomach;
    }
	
	function getHits_arms(){
        return $this->hits_arms;
    }
    function setHits_arms($hits_arms){
        $this->hits_arms = $hits_arms;
    }
	
	function getHits_legs(){
        return $this->hits_legs;
    }
    function setHits_legs($hits_legs){
        $this->hits_legs = $hits_legs;
    }

    function getAcc(){
        return $this->acc;
    }
    function setAcc(){
        $this->acc = round($this->hit * 100 / $this->shot);
    }

    function getInhead(){
        return $inhead->inhead;
    }
    function setInhead($inhead){
        $this->inhead = $inhead;
    }

    function getHelp(){
        return $help->help;
    }
    function setHelp($help){
        $this->help = $help;
    }

    function getLastgame(){
        return $this->lastgame;
    }
    function setLastgame($lastgame){
        $this->lastgame = $lastgame;
    }
    
    function connect($server){
        $host = $server->host;
        $charset = "UTF8";
        $db = $server->dbName;
        $user = $server->login;
        $pass = $server->pass;
        $port = $server->port;
        $dsn = "mysql:host=$host;port=$port;dbname=$db;charset=$charset";
        $opt = array(
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        );
        try {
            $pdo = new PDO($dsn, $user, $pass, $opt);
            return $pdo;
        } catch (Exception $ex) {
            echo 'Соединение оборвалось: ' , $ex->getMessage() , '<br><a href="mailto:', EMAIL ,'">При повторной ошибке сообщите администратору!</a>';
            exit();
        }
        
    }
    
    function convert64to32($id){
        $srx = (substr($sid, -1) % 2 == 0) ? 0 : 1;
        $arx = bcsub($sid, "76561197960265728");
        if (bccomp($arx, "0") != 1) { throw new InvalidArgumentException("Invalid SteamID"); }
        $arx = bcsub($arx, $srx);
        $arx = bcdiv($arx, 2);
        return sprintf("STEAM_1:%s:%s", $srx, $arx);
    }
}

?>