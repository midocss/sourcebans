<div class="row">
    <div class="header col-sm-12">
        <div class="header-content">
		
            <span class="pull-left">
                <a href="./"><img src="./includes/img/globalheader_logo.png" title="Logo"></a>
            </span>

            <span class="pull-right profile-nav">
                    <?php if(isset($_SESSION['steamid'])): ?>
                    <?php include_once('./includes/steamauth/userInfo.php'); ?>
                        <a class="user_name" href="./player.php"><?=$steamprofile['personaname']?></a>
                        <img class="user_avatar" src="<?=$steamprofile['avatar']?>">
                    <?php else:     ?>
                        <a class="user_name" href="./player.php?login" title="Авторизация"><?=auth?></a>
                    <?php endif;   ?>
            </span>

            <?php if(count($config['server']) != 1): // больше одного сервера ?>

                <span class="main_logo"></span>

                <a class="navA" href="./" title="На главную"><?=main_page?></a>

                <span class="server_logo"></span>

                <div class="dropdown">
                    <a href="#" class="dropbtn" title="Список серверов"><?=server?></a>
                    <div class="dropdown-content">
                        <?php for($i = 0; $i < count($config['server']); $i++): ?>
                            <a href=".?serv=<?=$i?>"><?=$config['server'][$i]['name']?></a>
                        <?php endfor; ?>
                    </div>
                </div>  

                <span class="search_logo"></span>

                <a class="navA" href="./search.php" title="Поиск игроков"><?=sh_head?></a>

            <?php else: // один сервер?>
                <span class="main_logo"></span> <a class="navA" href="./"><?=$config['server'][0]['name']?></a> <span class="search_logo"></span> <a class="navA" href="./search.php"><?=sh_head?></a> 
            <?php endif;?>

        </div>         
    </div>
</div>
<?php
    include_once("./includes/functions.php");
    dellCahe();
?>