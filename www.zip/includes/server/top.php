<div class="row">
    <div class="content col-sm-12">
        <div class="profile_content">
            <div class="profile_content_inner">
                <div class="row">                    
                        
                    <?php for($i=0; $i < count($config['server']); $i++): ?>
                        <?php $serer = new Server($config['server'][$i]['name'], $config['server'][$i]['host'], $config['server'][$i]['dbName'], $config['server'][$i]['login'], $config['server'][$i]['pass'], $config['server'][$i]['port']); ?>
                        <div class="row col-sm-12 recent_game table-responsive">
                            <script>
                                ava.push([]);
                                //console.log("log ava - ", ava);
                            </script>
                            <h4><?=$serer->name?></h4>
                            <?=all_player?>: <b><?=$serer->allPlayers()?></b>
                            <table class="table table-condensed table-striped">
                                <thead>
                                    <tr>
										<th>#</th>
										<th></th>
										<th><?=player?></th>
										<th><?=value?></th>
										<th><?=rank?></th>
										<th><?=kills?></th>
										<th><?=death?></th>
										<th><?=kd?></th>
										<th><?=shot?></th>
										<th><?=hits_all?></th>
										<th><?=acc?></th>
										<th><?=lastgame?></th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $data = $serer->top();
                                        for ($index = 0; $index < count($data); $index++): ?>
                                        <script>
                                            page = "top";
                                            servID = "<?=$i?>";
                                            playerId = "<?=steam32to64js($data[$index]["steam"])?>";
                                            //console.log(playerId);
                                            if(playerId != 0){
                                                ava[servID].push("<?=steam32to64($data[$index]["steam"])?>");
                                            }
                                            
                                        </script>
                                        <tr>
                                            <td><?=$index+1?></td>
                                            <td><img id="<?=steam32to64($data[$index]["steam"])?>" src="<?=checkAva(strval(steam32to64($data[$index]["steam"])))?>" width="32px" height="32px"></td>
                                            <td><a href="player.php?sid=<?=$data[$index]["steam"]?>"><?=$data[$index]["name"]?></a></td>
                                            <td><?=$data[$index]["value"]?></td>
                                            <td><img height="32px" img src="./includes/img/rank/<?=$config['LVL_18_OR_19']?>/<?=$data[$index]["rank"]?>.png"></td> 
                                            <td><?=$data[$index]["kills"]?></td>
                                            <td><?=$data[$index]["deaths"]?></td>
                                            <td><?php if($data[$index]["deaths"]!=0) { echo round($data[$index]["kills"]/$data[$index]["deaths"],2); }else{ echo 0; } ?></td>
                                            <td><?=$data[$index]["shoots"]?></td>
                                            <td><?=$data[$index]["hits_all"]?></td>
                                            <td><?php if($data[$index]["shoots"]!=0) { echo round($data[$index]["hits_all"]*100/$data[$index]["shoots"]); }else{ echo 0; } ?>%</td>
                                            <td><?=date("d.m.y", $data[$index]["lastconnect"])?></td>
                                        </tr>
                                    <?php endfor; ?>                        
                                </tbody>
                            </table>
                        </div>
                    <?php unset($serer); endfor; ?>

                </div>
            </div>
        </div>
    </div>
</div>